﻿namespace Pochita
{
    internal class Pet
    {
        public int Health { get; set; }
        public int Joy { get; set; }
        public int Null { get; set; }
        public int Toxic { get; set; }
     



        public void Feed(int amount)
        {
            Health += amount;
        }

        public void Hug(int amount)
        {
            Joy += amount;
        }

        public void Forfeit(int amount)
        {
            Null += amount;
        }
        public void Acid(int amount)
        {
            Toxic += amount;
        }
    }
}