using Pochita;

namespace Pochita_pet___sai_caraballo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Pet Pochita = new Pet();
        Pet Xeno = new Pet();
        private void button1_Click(object sender, EventArgs e) //feed pochita
        {
            Pochita.Feed(25);
            textBox1.Text = Pochita.Health.ToString();
        }


        private void button2_Click(object sender, EventArgs e) //hug pochita
        {
            Pochita.Hug(100);
            Pochita.Forfeit(1000);
            textBox2.Text = Pochita.Joy.ToString();

        }
        private void button3_Click(object sender, EventArgs e) //hit pochita
        {
            Pochita.Forfeit(-1000);
            Pochita.Hug(-1000);
            Pochita.Feed(-1000);
            textBox3.Text = Pochita.Null.ToString();
        }

        private void button4_Click(object sender, EventArgs e) //bread with jam
        {
            Pochita.Feed(1000);
            textBox1.Text = Pochita.Health.ToString();
        }

        private void button5_Click(object sender, EventArgs e) //Therapy
        {
            Pochita.Forfeit(1000);
            textBox3.Text = Pochita.Null.ToString();
        }
        private void Xeno_Click(object sender, EventArgs e) //rewrote button to make function. Also, xeno anger button
        {
            Xeno.Acid(1000);
            textBox3.Text = Xeno.Toxic.ToString();
        
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Pochita.Health -= 2;
            Pochita.Joy -= 2;
            textBox1.Text = Pochita.Health.ToString();
            textBox2.Text = Pochita.Joy.ToString(); 
        }

        private void button6_Click(object sender, EventArgs e) //xeno anger
        {
            pictureBox1.Image = Image.FromFile("Xeno.jpg");
            button3.Text = "Xeno Anger";
            button3.Click += new EventHandler (Xeno_Click); //change where button goes
            textBox7.Text = "Testing"; //when button pet xeno is clicked, textbox is changed
            //textBox1.Text = Pochita.Health.ToString(); change to xeno
            //textBox2.Text = Pochita.Joy.ToString(); //change to xeno

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
